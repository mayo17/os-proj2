compile using the following commands:

make memsim

run using the following commands

./memsim <tracefile name> <nframes> <fifo | lru | vms> <quiet | debug>